import 'package:encrypt/encrypt.dart';

dynamic iv = IV.fromLength(16);
dynamic key = Key.fromUtf8("thirtytwthirtytwthirtytwthirtytw");
dynamic encrypter = Encrypter(AES(key));
void main() {
  dynamic msg = "this #2 decrypted is encrypted msg";
  /*dynamic encrypted = encFunc(msg);
  dynamic decrypted = decFunc(encrypted);
  print(decrypted); // Lorem ipsum dolor sit amet, consectetur adipiscing elit
  print(encrypted.base64);*/
  String encmsg = encFunc1(msg);
  print("encmsg=> $encmsg");
  String decmsg = decFunc1(encmsg);
  print('decmsg=> $decmsg');
}

String encFunc1(String encvar) {
  dynamic enc = encrypter.encrypt(encvar, iv: iv);
  return enc.base64;
}

dynamic encFunc(dynamic encvar) {
  encvar = encrypter.encrypt(encvar, iv: iv);
  return encvar;
}

dynamic decFunc(dynamic encvar) {
  dynamic decvar = encrypter.decrypt(encvar, iv: iv);
  return decvar;
}

String decFunc1(String encvar) {
  String decvar = encrypter.decrypt64(encvar, iv: iv);
  return decvar;
}
