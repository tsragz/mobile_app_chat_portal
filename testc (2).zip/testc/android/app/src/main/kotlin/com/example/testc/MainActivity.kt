package com.example.testc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
